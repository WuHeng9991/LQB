#ifndef __ONEWIRE_H__
#define __ONEWIRE_H__
#include <STC15F2K60S2.H>
#include "intrins.h"
sbit DQ = P1^4;
float DS18B02_Read();




#endif
