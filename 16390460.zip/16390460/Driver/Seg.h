#ifndef __SEG_H__
#define __SEG_H__
#include <STC15F2K60S2.H>
void Seg_Disp(unsigned char Dula,unsigned char Wela,unsigned char Point);



#endif
