#ifndef __INIT_H__
#define __INIT_H__
#include <STC15F2K60S2.H>
void System_Init();



#endif
