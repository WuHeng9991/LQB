#include "Led.h"
static unsigned char temp2=0x00;
static unsigned char temp2_Old=0xff;
void Led_Disp(unsigned char add,unsigned char Enable)
{
	unsigned char temp=0;
	static unsigned char temp1=0x00;
	static unsigned char temp1_Old=0xff;
	if(Enable)
	temp1 |= 0x01<<add;
	else
	temp1 &= ~(0x01<<add);
	
	if(temp1!=temp1_Old)
	{
		P0 = ~temp1;
		
		temp = P2&0x1f;
		temp = temp|0x80;
		P2 = temp;
		temp = temp&0x1f;
		P2 = temp;
	}
	temp1_Old = temp1;

}


void Relay(bit Enable)
{
	unsigned char temp=0;
	if(Enable)
	temp2 |= 0x10;
	else
	temp2 &= ~(0x10);
	
	if(temp2!=temp2_Old)
	{
		P0 = temp2;
		
		temp = P2&0x1f;
		temp = temp|0xa0;
		P2 = temp;
		temp = temp&0x1f;
		P2 = temp;
	}
	temp2_Old=temp2;

}