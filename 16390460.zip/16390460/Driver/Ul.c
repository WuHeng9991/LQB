#include "Ul.h"
void Delay12us(void)	//@12.000MHz
{
	unsigned char data i;

	_nop_();
	_nop_();
	i = 38;
	while (--i);
}

void UL_Init()
{
	unsigned char i=0;
	for(i=0;i<8;i++)
	{
		Tx = 1;
		Delay12us();
		Tx = 0;
		Delay12us();
	}
}

unsigned char Ul_Read()
{
	unsigned int time;
	CMOD = 0x00;
	CL = CH = 0;
	EA = 0;
	UL_Init();
	EA = 1;
	CR = 1;
	while(Rx==1 && CF==0);
	CR = 0;
	if(CF==1)
	{
		CF = 0;
		return 0;
	}
	else
	{
		time = (CH<<8)|CL;
		return time * 0.017;
	}


	
}