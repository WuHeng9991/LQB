#ifndef __UL_H__
#define __UL_H__
#include <STC15F2K60S2.H>
#include "INTRINS.H"
sbit Tx=P1^0;
sbit Rx=P1^1;
unsigned char Ul_Read();

#endif
