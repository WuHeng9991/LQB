#include "Key.h"

unsigned char Key_Disp()
{
	unsigned char KeyNum=0;
	P44=0;P42=1;P35=1;P34=1;
	if(P30==0){KeyNum=7;}
	if(P31==0){KeyNum=6;}
	if(P32==0){KeyNum=5;}
	if(P33==0){KeyNum=4;}
	
	P44=1;P42=0;P35=1;P34=1;
	if(P30==0){KeyNum=11;}
	if(P31==0){KeyNum=10;}
	if(P32==0){KeyNum=9;}
	if(P33==0){KeyNum=8;}	
	if(P32==0 && P33==0)
	{
		KeyNum=89;
	}
	P44=1;P42=1;P35=0;P34=1;
	if(P30==0){KeyNum=15;}
	if(P31==0){KeyNum=14;}
	if(P32==0){KeyNum=13;}
	if(P33==0){KeyNum=12;}	
	
	P44=1;P42=1;P35=1;P34=0;
	if(P30==0){KeyNum=19;}
	if(P31==0){KeyNum=18;}
	if(P32==0){KeyNum=17;}
	if(P33==0){KeyNum=16;}

	return KeyNum;
	
}