#ifndef __KEY_H__
#define __KEY_H__
#include <STC15F2K60S2.H>
unsigned char Key_Disp();



#endif
