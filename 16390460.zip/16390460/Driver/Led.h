#ifndef __LED_H__
#define __LED_H__
#include <STC15F2K60S2.H>
void Led_Disp(unsigned char add,unsigned char Enable);
void Relay(bit Enable);



#endif
