#include "Seg.h"
code unsigned char Seg_Dula[] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff,0xc6,0xc8,0xc7,0x8c};
code unsigned char Seg_Wela[] = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
void Seg_Disp(unsigned char Dula,unsigned char Wela,unsigned char Point)
{
	unsigned char temp;
	/*消影*/
	P0 = 0xff;
	
	temp = P2&0x1f;
	temp = temp|0xe0;
	P2 = temp;
	temp = temp&0x1f;
	P2 = temp;
	
	/*位选*/
	P0 = Seg_Wela[Wela];
	
	temp = P2&0x1f;
	temp = temp|0xc0;
	P2 = temp;
	temp = temp&0x1f;
	P2 = temp;
	
	/*段选*/
	P0 = Seg_Dula[Dula];
	if(Point)
	P0 &= 0x7f;
	temp = P2&0x1f;
	temp = temp|0xe0;
	P2 = temp;
	temp = temp&0x1f;
	P2 = temp;
	
	
}