#ifndef __IIC_H__
#define __IIC_H__
#include "intrins.h"
#include <STC15F2K60S2.H>

sbit scl = P2^0;
sbit sda = P2^1;
unsigned char AD_Read(unsigned char add);



#endif
