/*头文件声明区*/
#include <STC15F2K60S2.H>
#include "Key.h"
#include "Init.h"
#include "Seg.h"
#include "Led.h"
#include "onewire.h"
#include "iic.h"
#include "Ul.h"
#include "intrins.h"

/*变量声明区*/
unsigned char Key_Val,Key_Down,Key_Up,Key_Old;//按键检测变量
unsigned char Key_Slow;//按键频率变量
unsigned char Seg_Slow;//数码管频率变量
idata unsigned char Seg_Pos;//数码管扫描变量
idata unsigned char Seg_Buf[] = {10,10,10,10,10,10,10,10};//数码管显示数组
idata unsigned char Led_Buf[] = {0,0,0,0,0,0,0,0};//LED显示数组
idata unsigned char Seg_Point[] = {0,0,0,0,0,0,0,0};//小数点
unsigned char Seg_Mode;//数码管显示模式 
unsigned char Work_Mode;//0-温度参数界面，1-距离参数界面
float T_Data;//温度接收变量
unsigned char AD_Value;//AD值接收
unsigned char AD_Dji;//AD等级
unsigned char YD_Sta;//运动状态 0-为静止，1-为徘徊，2-为跑动
unsigned char Ul_Data;//超声波测距变量
unsigned char T_Set=30;//温度设置变量
unsigned char T_Disp=30;//温度显示变量
unsigned char JL_Set=30;//距离设置变量
unsigned char JL_Disp=30;//距离显示变量
unsigned int Time1000ms;//1S延迟
unsigned char JL_Index;//距离检测索引
unsigned char JL_Data[2];//距离存储数组
unsigned char JL_Value;//距离数值的差
unsigned char JL_Temp;//距离数值的中间值，来锁定使用
bit YD_Sta_Flag=1;//运动状态标志位
unsigned int Time3000ms;//3S延迟
bit JJ_Flag;//接近判断标志位
unsigned char Time100ms;//100ms延迟
bit Led_Flag;//闪烁标志位
unsigned int Relay_Num;//数码管吸合次数
unsigned int Time2000ms;//延迟2000ms
bit Relay_Out;//继电器清零标志位
/*按键检测区*/
void Key_Proc()
{
	if(Key_Slow<10) return;
	Key_Slow=0;
	
	Key_Val = Key_Disp();
	Key_Down = Key_Val&(Key_Val^Key_Old);
	Key_Up = ~Key_Val&(Key_Val^Key_Old);
	Key_Old = Key_Val;
	
	switch(Key_Down)
	{
		case 4://显示界面切换
			if(++Seg_Mode==4){Seg_Mode=0;}
		break;
		case 5://参数设置界面子界面切换
			if(Seg_Mode==2)//在参数设置界面下
			{
				Work_Mode^=1;
			}
		break;
		case 8://加加
			if(Seg_Mode==2)//参数设置界面下
			{
				if(Work_Mode==0)//温度设置界面下
				{
					if(++T_Disp>80)
					{
						T_Disp=80;
					}
					
				}
				else//距离设置界面下
				{
					if((JL_Disp += 5)>80)
					{
						JL_Disp=80;
					}
				}
			}
		break;
		case 9://减减
			if(Seg_Mode==2)//参数设置界面下
			{
				if(Work_Mode==0)//温度设置界面下
				{
					if(--T_Disp<20)
					{
						T_Disp=20;
					}
					
				}
				else//距离设置界面下
				{
					if((JL_Disp -= 5)<20)
					{
						JL_Disp=20;
					}
				}
			}
		break;
				
	}
	if(Seg_Mode==3)//统计界面下
	{
		if(Key_Old==89 && Relay_Out==1)//继电器清零
		{
			Relay_Num=0;
			Relay_Out=0;
		}
	}
			

}


/*数码管显示区*/
void Seg_Proc()
{
	if(Seg_Slow<80) return;
	Seg_Slow=0;
	T_Data = DS18B02_Read();
	AD_Value = AD_Read(0x41)/51.0;
	Ul_Data = Ul_Read();
	if(AD_Value>=3)
	{
		AD_Dji=1;
	}
	else if(AD_Value>=2 && AD_Value<3)
	{
		AD_Dji=2;
	}
	else if(AD_Value>=0.5 && AD_Value<2)
	{
		AD_Dji=3;
	}
	else
	{
		AD_Dji=4;
	}
	switch(Seg_Mode)
	{
		case 0://环境状态界面
			Seg_Buf[0]=11;
			Seg_Buf[1]=(unsigned char)T_Data/10%10;
			Seg_Buf[2]=(unsigned char)T_Data%10;
		
			Seg_Buf[6]=12;
			Seg_Buf[7]=AD_Dji;
			
		break;
		
		case 1://运动检测界面			
			Seg_Buf[0]=13;
			Seg_Buf[1]=YD_Sta;
			Seg_Buf[2]=10;
		
			Seg_Buf[5]=Ul_Data/100%10;
			Seg_Buf[6]=Ul_Data/10%10;
			Seg_Buf[7]=Ul_Data%10;
		break;
		
		case 2://参数设置界面
			if(Work_Mode==0)//温度参数界面
			{
				Seg_Buf[0] = 14;
				Seg_Buf[1] = 11;
				Seg_Buf[5] = 10;
				Seg_Buf[6] = T_Disp/10%10;
				Seg_Buf[7] = T_Disp%10;
			}
			else//距离参数界面
			{
				Seg_Buf[0] = 14;
				Seg_Buf[1] = 13;
				Seg_Buf[5] = 10;
				Seg_Buf[6] = JL_Disp/10%10;
				Seg_Buf[7] = JL_Disp%10;
			}
		break;
		case 3://统计数据界面
				Work_Mode = 0;
				JL_Set=JL_Disp;
				T_Set=T_Disp;
				Seg_Buf[0] = 12;
				Seg_Buf[1] = 11;
		
		Seg_Buf[4] = (Relay_Num/1000%10)==0?10:(Relay_Num/1000%10);
		if(Seg_Buf[4]==10)
		Seg_Buf[5] = (Relay_Num/100%10)==0?10:(Relay_Num/100%10);
		else
		Seg_Buf[5] = Relay_Num/100%10;
		if(Seg_Buf[5]==10)
		Seg_Buf[6] = (Relay_Num/10%10)==0?10:(Relay_Num/10%10);
		else
		Seg_Buf[6] = Relay_Num/10%10;
		Seg_Buf[7] = Relay_Num%10;		

		break;
	}
	
}

/*led显示区*/
void Led_Proc()
{
		unsigned char i=0;
		if(YD_Sta_Flag)
		{
			if(JL_Value<5)
				{
					YD_Sta = 1;
				}
				else if(JL_Value>=5 && JL_Value<10)
				{
					YD_Sta = 2;
				}
				else
				{
					YD_Sta = 3;
				}
		}
			
		if(JL_Temp !=YD_Sta)
		{
			YD_Sta_Flag = 0;
		}
		JL_Temp = YD_Sta;//更新运动状态
	
	if(Ul_Data<JL_Set)
	{
			if(YD_Sta==3)
			{
				for(i=0;i<4;i++)
				{
					Led_Buf[i] = (i == YD_Sta-1) ||	(i == YD_Sta-2) || (i == YD_Sta-3);
				}
			}
			else if(YD_Sta==2)
			{
				for(i=0;i<4;i++)
				{
					Led_Buf[i] = (i == YD_Sta-1) ||	(i == YD_Sta-2);
				}
			}
			else if(YD_Sta==1)
			{
				for(i=0;i<4;i++)
				{
					Led_Buf[i] = (i == YD_Sta-1);
				}
			}
			
	}
	else
	{
		for(i=0;i<4;i++)
		{
			Led_Buf[i] = 0;
		}
	}
	
	if(YD_Sta==2 || YD_Sta==1)//静止或者徘徊状态时
	{
		Led_Buf[7] = YD_Sta-1;
	}
	else if(YD_Sta==3)//跑动
	{
		 Led_Buf[7] = Led_Flag;
	}
	
	if((T_Set<T_Data) && (Ul_Data<JL_Set))//高温状态下并且处于接近状态
	{
		Relay(1);
		Relay_Num++;
	}
	else
	{
		Relay(0);
	}
}

/*定时器0*/
void Timer0_Init(void)		//1毫秒@12.000MHz
{
	AUXR &= 0x7F;			//定时器时钟12T模式
	TMOD &= 0xF0;			//设置定时器模式
	TL0 = 0x18;				//设置定时初始值
	TH0 = 0xFC;				//设置定时初始值
	TF0 = 0;				//清除TF0标志
	TR0 = 1;				//定时器0开始计时
	ET0 = 1;				//使能定时器0中断
	EA = 1;
}

/*定时器0中断服务函数*/
void Timer0_Isr(void) interrupt 1
{
	Key_Slow++;
	Seg_Slow++;
	if(++Seg_Pos==8){Seg_Pos=0;}
	Seg_Disp(Seg_Buf[Seg_Pos],Seg_Pos,Seg_Point[Seg_Pos]);
	Led_Disp(Seg_Pos,Led_Buf[Seg_Pos]);
	if(++Time1000ms==1000)
	{
		Time1000ms=0;
		JL_Data[JL_Index] = Ul_Data;
		
		if(++JL_Index==2)
		{
			if(JL_Data[1]>=JL_Data[0])
			JL_Value = JL_Data[1]-JL_Data[0];
			else
			JL_Value = JL_Data[0]-JL_Data[1];
			JL_Index=0;
		}
	}
	if(YD_Sta_Flag==0)
	{
		if(++Time3000ms==3000){Time3000ms=0;YD_Sta_Flag=1;}
	}
	if(++Time100ms==100){Time100ms=0;Led_Flag^=1;}
	if(Key_Old==89)
	{
		if(++Time2000ms==2000){Time2000ms=0;Relay_Out=1;}
	}
	
}

void Delay750ms(void)	//@12.000MHz
{
	unsigned char data i, j, k;

	_nop_();
	_nop_();
	i = 35;
	j = 51;
	k = 182;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}

/*main*/
void main()
{
	System_Init();
	Timer0_Init();
	T_Data = DS18B02_Read();
	Delay750ms();
	while(1)
	{
		Key_Proc();
		Seg_Proc();
		Led_Proc();
	}
}